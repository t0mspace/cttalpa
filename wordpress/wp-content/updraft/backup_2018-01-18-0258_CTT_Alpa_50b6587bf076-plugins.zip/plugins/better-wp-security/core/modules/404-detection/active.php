<?php

require_once( 'class-itsec-four-oh-four.php' );
$itsec_404_detection = new ITSEC_Four_Oh_Four();
$itsec_404_detection->run();
