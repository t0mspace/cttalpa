<?php
/**
 * Author: Ole Fredrik Lie
 * URL: http://olefredrik.com
 *
 * FoundationPress functions and definitions
 *
 * Set up the theme and provides some helper functions, which are used in the
 * theme as custom template tags. Others are attached to action and filter
 * hooks in WordPress to change core functionality.
 *
 * @link https://codex.wordpress.org/Theme_Development
 * @package FoundationPress
 * @since FoundationPress 1.0.0
 */

/** Various clean up functions */
require_once( 'library/cleanup.php' );

/** Required for Foundation to work properly */
require_once( 'library/foundation.php' );

/** Format comments */
require_once( 'library/class-foundationpress-comments.php' );

/** Register all navigation menus */
require_once( 'library/navigation.php' );

/** Add menu walkers for top-bar and off-canvas */
require_once( 'library/class-foundationpress-top-bar-walker.php' );
require_once( 'library/class-foundationpress-mobile-walker.php' );

/** Create widget areas in sidebar and footer */
require_once( 'library/widget-areas.php' );

/** Return entry meta information for posts */
require_once( 'library/entry-meta.php' );

/** Enqueue scripts */
require_once( 'library/enqueue-scripts.php' );

/** Add theme support */
require_once( 'library/theme-support.php' );

/** Add Nav Options to Customer */
require_once( 'library/custom-nav.php' );

/** Change WP's sticky post class */
require_once( 'library/sticky-posts.php' );

/** Configure responsive image sizes */
require_once( 'library/responsive-images.php' );

/** If your site requires protocol relative url's for theme assets, uncomment the line below */
// require_once( 'library/class-foundationpress-protocol-relative-theme-assets.php' );


// increase `timeout` for `api.wordpress.org` requests
add_filter( 'http_request_args', function( $request, $url ) {

    if ( strpos( $url, '://api.wordpress.org/' ) !== false ) {
        $request[ 'timeout' ] = 15;
    }

    return $request;

}, 10, 2 );

add_filter('envira_gallery_output_before_image', 'enfold_envira_gallery_output_before_image', 10, 5);
function enfold_envira_gallery_output_before_image( $output, $id, $item, $data, $i ) {
    $output = str_replace('envira-gallery-link', 'envira-gallery-link noHover', $output);
    return $output;
}


/**security function: avoid display of wordpress version
 *
 */
remove_action("wp_head", "wp_generator");



// Replaces the excerpt "Read More" text by a link
function new_excerpt_more($more) {
    global $post;
    return '<a class="read-more small" href="'. get_permalink($post->ID) . '">Lire plus</a>';
}
add_filter('excerpt_more', 'new_excerpt_more');


// Upload location modification

add_filter('wp_handle_upload_prefilter', 'so_8519968_handle_upload_prefilter');
add_filter('wp_handle_upload', 'so_8519968_handle_upload');

function so_8519968_handle_upload_prefilter( $file )
{
    add_filter('upload_dir', 'so_8519968_custom_upload_dir');
    return $file;
}

function so_8519968_handle_upload( $fileinfo )
{
    remove_filter('upload_dir', 'so_8519968_custom_upload_dir');
    return $fileinfo;
}

function so_8519968_custom_upload_dir( $path )
{
    // Check if uploading from inside a post/page/cpt - if not, default Upload folder is used
    $use_default_dir = ( isset($_REQUEST['post_id'] ) && $_REQUEST['post_id'] == 0 ) ? true : false;
    if( !empty( $path['error'] ) || $use_default_dir )
        return $path;

    // Check if correct post type
    $the_post_type = get_post_type( $_REQUEST['post_id'] );
    if( 'sponsor' != $the_post_type )
        return $path;

    $customdir = DIRECTORY_SEPARATOR.'sponsors'.DIRECTORY_SEPARATOR;

    //remove default subdir (year/month) and add custom dir INSIDE THE DEFAULT UPLOAD DIR
    $path['path']    = str_replace( $path['subdir'], $customdir, $path['path']);
    $path['url']     = str_replace( $path['subdir'], $customdir, $path['url']);

    $path['subdir']  = $customdir;

    return $path;
}





//
//function post_type_sponsor() {
//    $labels = array(
//        'name'               => 'Sponsors',
//        'singular_name'      => 'Sponsor',
//        'menu_name'          => 'Sponsor',
//        'name_admin_bar'     => 'Sponsor',
//        'add_new'            => 'Add New',
//        'add_new_item'       => 'Add New Sponsor',
//        'new_item'           => 'New Sponsor',
//        'edit_item'          => 'Edit Sponsor',
//        'view_item'          => 'View Sponsor',
//        'all_items'          => 'All Sponsors',
//        'search_items'       => 'Search Sponsors',
//        'parent_item_colon'  => 'Parent Sponsors:',
//        'not_found'          => 'No Sponsors found.',
//        'not_found_in_trash' => 'No Sponsors found in Trash.'
//    );
//
//    $args = array(
//        'public'      => true,
//        'labels'      => $labels,
//        'description' => 'Sponsor'
//    );
//    register_post_type( 'sponsor', $args );
//}
//add_action( 'init', 'post_type_sponsor' );



//function post_type_slider() {
//
//// Set UI labels for Custom Post Type
//    $labels = array(
//        'name'                => _x( 'Sliders', 'Post Type General Name', 'Vin' ),
//        'singular_name'       => _x( 'Slider', 'Post Type Singular Name', 'Vin' ),
//        'menu_name'           => __( 'Slider', 'Vin' ),
//        'parent_item_colon'   => __( 'Parent Slider', 'Vin' ),
//        'all_items'           => __( 'All Sliders', 'Vin' ),
//        'view_item'           => __( 'View this Slider', 'Vin' ),
//        'add_new_item'        => __( 'Add New Slider', 'Vin' ),
//        'add_new'             => __( 'Add New Slider', 'Vin' ),
//        'edit_item'           => __( 'Edit Slider', 'Vin' ),
//        'update_item'         => __( 'Update Slider', 'Vin' ),
//        'featured_image'	  => __( 'Slider Image', 'Vin'),
//        'set_featured_image'  => __( 'Set Slider Image', 'Vin'),
//        'remove_featured_image'   => __( 'Remove Slider Image', 'Vin'),
//        'use_featured_image'  => __( 'Use Slider Image', 'Vin'),
//        'search_items'        => __( 'Search Slider', 'Vin' ),
//        'not_found'           => __( 'Not Found', 'Vin' ),
//        'not_found_in_trash'  => __( 'Not found in Trash', 'Vin' ),
//    );
//
//// Set other options for Custom Post Type
//
//    $args = array(
//        'label'               => __( 'sliders', 'Vin' ),
//        'description'         => __( 'Slider for Home page', 'Vin' ),
//        'labels'              => $labels,
//        // Features this CPT supports in Post Editor
//        'supports'            => array( 'title','thumbnail'),
//        /* A hierarchical CPT is like Pages and can have
//        * Parent and child items. A non-hierarchical CPT
//        * is like Posts.
//        */
//        'hierarchical'        => false,
//        'public'              => false,
//        'show_ui'             => true,
//        'show_in_menu'        => true,
//        'show_in_nav_menus'   => true,
//        'show_in_admin_bar'   => true,
//        'menu_position'       => 5,
//        'can_export'          => true,
//        'has_archive'         => false,
//        'rewrite'			  => false,
//        'exclude_from_search' => false,
//        'publicly_queryable'  => false,
//        'capability_type'     => 'page',
//    );
//
//    // Registering your Custom Post Type
//    register_post_type( 'sliders', $args );
//
//}
//add_action( 'init', 'post_type_slider', 0 );

function gkp_add_slug_body_class( $classes )
{

    if ( is_page() )
    {
        global $post;
        $classes[] = $post->post_type . '-' . $post->post_name;
    }

    return $classes;
}
add_filter( 'body_class', 'gkp_add_slug_body_class' );


