<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package FoundationPress
 * @since FoundationPress 1.0.0
 */

get_header();

//get_template_part( 'template-parts/featured-image' );

?>

<div class="main-wrap">
	<main class="main-content">
		<?php while ( have_posts() ) : the_post(); ?>
			<?php get_template_part( 'template-parts/content', '' ); ?>


            <?php $related = get_posts( array( 'category__in' => wp_get_post_categories(the_ID()), 'numberposts' => 3, 'post__not_in' => array($post->ID) ) );
            if( $related){?>
                <h4>Autres articles dans la même catégorie</h4>
                <div class="row small-up-2 medium-up-3 large-up-3">

                <?php
                foreach( $related as $post )
                {
                    setup_postdata($post); ?>
                        <div class="column">
                            <a href="<?php the_permalink(); ?>">
                                 <div class="card">
                                    <?php the_post_thumbnail('featured-small');?>
                                    <div class="card-section">
                                        <h4><?php the_title(); ?></h4>
                                    </div>
                                </div>
                            </a>
                        </div>


                <?php
                }?>
                    </div>
                </div>
                <?php
            } wp_reset_postdata(); ?>
		<?php endwhile;?>

	</main>

</div>
<?php get_footer();
